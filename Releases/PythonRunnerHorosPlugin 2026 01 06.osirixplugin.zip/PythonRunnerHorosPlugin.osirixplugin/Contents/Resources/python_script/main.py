def main():
    print("Hello world!", flush=True)


if __name__ == "__main__":
    main()
